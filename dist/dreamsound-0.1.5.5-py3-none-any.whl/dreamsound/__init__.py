###############################################################################
#
#  This file is part of the dreamsound package.
#  
#  packate initialization routines
#
###############################################################################
from .dreamsound import DreamSound
