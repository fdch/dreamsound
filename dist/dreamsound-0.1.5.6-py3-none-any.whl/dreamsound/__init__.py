###############################################################################
#
#  This file is part of the dreamsound package.
#  
#  packate initialization routines
#
###############################################################################
from .dreamsound import DreamSound
__version__ = "0.1.5.6"